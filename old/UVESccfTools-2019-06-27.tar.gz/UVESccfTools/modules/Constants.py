RJup = 69911.			# Jupiter radius in km
MJup = 1.898E27			# Jupiter mass in kg
MSun = 1.989E30         # Sun mass in kg
RSun = 696000.          # Sun Radius in km
AU = 149597871.			# Astronomical Unit in km

