#!/usr/bin/env python
maxBERV = 30000.  # maximum value of the Barycentric Earth Radial Velocity in m/s
c = 299792458.  # speed of light in m/s
