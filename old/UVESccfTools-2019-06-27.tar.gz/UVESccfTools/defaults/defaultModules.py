# global sys, os, np
# import sys,os
# import numpy as np

globals()['os'] = __import__('os')
