night       =   'test01'
ccfMask     = 'newG2'
theoRV      = 0.0
ccfWidth    = 200.
ccfStep     = 0.5
